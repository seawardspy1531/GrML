import os, sys

from distutils.core import setup, Extension
from distutils import sysconfig

cpp_args = ['-std=c++17', '-stdlib=libc++']

grml_module = Extension(
    'GrML', sources=['GrML.cpp'],
    include_dirs=['pybind11/pybind11/include/pybind11/pybind11.h'],
    language='c++',
    extra_compile_args=cpp_args,
    )

setup(
    name='GrML',
    version='1.0',
    description='GrML C++ source library',
    ext_modules=[grml_module]
)